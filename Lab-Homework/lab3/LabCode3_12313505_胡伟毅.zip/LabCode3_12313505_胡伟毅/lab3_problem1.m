%% Lab 3 - Problem 1
% Synthesize vowels /a/ /i/ /u/ using pure tones:
% 1) Sample spectral envelopes from Lab2 vowel recordings.
% 2) Synthesize vowels with F0 = 150 Hz (male), 250 Hz (female).
% 3) Plot waveform / spectrum / spectrogram.
% 4) Save synthesized wav files.

clear; clc; close all;
rng(20260313, "twister");

outDir = fullfile(pwd, "lab3_outputs", "problem1");
if ~exist(outDir, "dir")
    mkdir(outDir);
end

% Prefer the exact folder you provided; fallback to auto search if needed.
preferredVowelDir = "/Users/hwy/Desktop/个人/26春/语音信号处理/LabCode2_12313505_胡伟毅";
aWav = locateWithPreferredDir(preferredVowelDir, "problem2_a.wav");
iWav = locateWithPreferredDir(preferredVowelDir, "problem2_i.wav");
uWav = locateWithPreferredDir(preferredVowelDir, "problem2_u.wav");

fprintf("Using input files:\n");
fprintf("  /a/: %s\n", aWav);
fprintf("  /i/: %s\n", iWav);
fprintf("  /u/: %s\n\n", uWav);

vowels = ["a", "i", "u"];
vowelFiles = {aWav, iWav, uWav};
f0List = [150, 250];
voiceName = ["male", "female"];
durSec = 1.0;
fsSyn = 16000;

%% 1) Sample spectral envelopes
envData = struct();
for k = 1:numel(vowels)
    [xv, fsv] = audioread(vowelFiles{k});
    xv = toMonoColumn(xv);
    [fEnv, envDb] = estimateSpectralEnvelope(xv, fsv);

    fEnv = fEnv(:);
    envDb = envDb(:);
    envData(k).vowel = vowels(k); %#ok<SAGROW>
    envData(k).fHz = fEnv;
    envData(k).envDb = envDb;
    envData(k).xOrig = xv;
    envData(k).fsOrig = fsv;

    T = table(fEnv, envDb, 'VariableNames', {'Frequency_Hz', 'Envelope_dB'});
    writetable(T, fullfile(outDir, sprintf("P1_env_%s.csv", vowels(k))));
end

%% 2) Synthesize vowels
synth = struct();
for g = 1:numel(f0List)
    f0 = f0List(g);
    for k = 1:numel(vowels)
        y = synthVowelFromEnvelope(envData(k).fHz, envData(k).envDb, fsSyn, f0, durSec);
        y = 0.98 * y / (max(abs(y)) + eps);

        synth(g, k).voice = voiceName(g); %#ok<SAGROW>
        synth(g, k).vowel = vowels(k);
        synth(g, k).y = y;
        synth(g, k).fs = fsSyn;

        outWav = fullfile(outDir, sprintf("P1_%s_%s_F0%d.wav", voiceName(g), vowels(k), f0));
        audiowrite(outWav, y, fsSyn);
    end
end

%% 3) Plot waveform / spectrum / spectrogram (one vowel per figure)
for g = 1:numel(f0List)
    for k = 1:numel(vowels)
        ySyn = synth(g, k).y;
        fsSynNow = synth(g, k).fs;

        % Prepare original recording for comparison.
        xOrig = envData(k).xOrig;
        fsOrig = envData(k).fsOrig;
        xOrig = ensureFs(xOrig, fsOrig, fsSynNow);

        fig = figure("Name", sprintf("P1-%s-/%s/", voiceName(g), vowels(k)), ...
            "Color", "w");
        tl = tiledlayout(3, 1, "Padding", "compact", "TileSpacing", "compact");
        title(tl, sprintf("Original vs Synthesized /%s/ (%s, F0=%d Hz)", ...
            vowels(k), voiceName(g), f0List(g)));

        % (1) Time-domain comparison.
        showDur = 0.05;  % 50 ms
        segOrig = extractSteadySegment(xOrig, fsSynNow, showDur);
        segSyn = extractSteadySegment(ySyn, fsSynNow, showDur);
        segOrig = segOrig / (max(abs(segOrig)) + eps);
        segSyn = segSyn / (max(abs(segSyn)) + eps);
        t = (0:numel(segSyn)-1).' / fsSynNow;

        nexttile;
        plot(t, segOrig, "Color", [0.70, 0.70, 0.70], "LineWidth", 1.3); hold on;
        plot(t, segSyn, "b", "LineWidth", 1.6);
        grid on;
        xlabel("Time (s)");
        ylabel("Normalized Amplitude");
        title(sprintf("Waveform Comparison: Original vs Synthesized /%s/", vowels(k)));
        legend("Original (Weakened)", "Synthesized (Highlighted)", "Location", "best");

        % (2) Spectrum comparison + sampled envelope.
        specDur = 0.04;  % 40 ms
        specOrig = extractSteadySegment(xOrig, fsSynNow, specDur);
        specSyn = extractSteadySegment(ySyn, fsSynNow, specDur);
        [fOrig, mOrig] = oneSidedSpectrum(specOrig, fsSynNow);
        [fSyn, mSyn] = oneSidedSpectrum(specSyn, fsSynNow);
        mOrig = mOrig - max(mOrig);
        mSyn = mSyn - max(mSyn);

        nexttile;
        plot(fOrig, mOrig, "Color", [0.70, 0.70, 0.70], "LineWidth", 1.2); hold on;
        plot(fSyn, mSyn, "b", "LineWidth", 1.4);
        plot(envData(k).fHz, envData(k).envDb - max(envData(k).envDb), "r--", ...
            "LineWidth", 2.0);
        xlim([0 4000]);
        grid on;
        xlabel("Frequency (Hz)");
        ylabel("Normalized Magnitude (dB)");
        title("Spectrum Comparison with Sampled Envelope");
        legend("Original Spectrum", "Synthesized Spectrum", "Sampled Envelope", ...
            "Location", "best");

        % (3) Spectrogram of synthesized vowel.
        nexttile;
        spectrogram(ySyn, round(0.02*fsSynNow), round(0.01*fsSynNow), 1024, ...
            fsSynNow, "yaxis");
        title(sprintf("Spectrogram of Synthesized /%s/", vowels(k)));
        ylim([0 4]);
        xlabel("Time (ms)");
        ylabel("Frequency (kHz)");

        outFig = fullfile(outDir, sprintf("P1_%s_%s_compare_3plots.png", ...
            voiceName(g), vowels(k)));
        saveas(fig, outFig);
    end
end

fprintf("Problem 1 done.\nOutputs saved in: %s\n", outDir);

%% Local functions
function p = locateWithPreferredDir(preferredDir, fileName)
    pPreferred = fullfile(preferredDir, fileName);
    if isfile(pPreferred)
        p = pPreferred;
        return;
    end
    p = locateSingleFile(fileName);
end

function p = locateSingleFile(fileName)
    p = fullfile(pwd, fileName);
    if isfile(p)
        return;
    end

    homeDir = char(java.lang.System.getProperty("user.home"));
    roots = {fullfile(homeDir, "Desktop"), fullfile(homeDir, "Documents"), homeDir};
    for r = 1:numel(roots)
        rootNow = roots{r};
        if ~isfolder(rootNow)
            continue;
        end
        hits = dir(fullfile(rootNow, "**", fileName));
        if ~isempty(hits)
            [~, idx] = max([hits.datenum]);
            p = fullfile(hits(idx).folder, hits(idx).name);
            return;
        end
    end

    error("Cannot find required file: %s", fileName);
end

function x = toMonoColumn(x)
    if size(x, 2) > 1
        x = mean(x, 2);
    end
    x = x(:);
end

function [f, envDb] = estimateSpectralEnvelope(x, fs)
    x = toMonoColumn(x);
    x = x - mean(x);

    frameLen = max(round(0.03*fs), 256);
    hop = max(round(0.01*fs), 64);

    if numel(x) < frameLen
        frame = x;
    else
        [st, en] = bestEnergyFrame(x, frameLen, hop);
        frame = x(st:en);
    end

    w = hamming(numel(frame));
    nfft = 8192;
    X = fft(frame .* w, nfft);
    X = X(1:nfft/2+1);
    f = (0:nfft/2).' * fs / nfft;
    magDb = 20*log10(abs(X) + 1e-12);
    envDb = smoothByMovingAverage(magDb, 121);
end

function [st, en] = bestEnergyFrame(x, L, hop)
    n = numel(x);
    idx = 1:hop:(n-L+1);
    e = zeros(numel(idx), 1);
    for i = 1:numel(idx)
        seg = x(idx(i):idx(i)+L-1);
        e(i) = sum(seg.^2);
    end
    [~, k] = max(e);
    st = idx(k);
    en = st + L - 1;
end

function y = synthVowelFromEnvelope(fEnv, envDb, fs, f0, durSec)
    n = round(durSec * fs);
    t = (0:n-1).' / fs;

    maxH = floor((fs/2) / f0);
    h = (1:maxH).';
    fH = h * f0;

    ampDb = interp1(fEnv, envDb, fH, "linear", "extrap");
    ampLin = 10.^((ampDb - max(ampDb)) / 20);
    ampLin = ampLin ./ sqrt(h);

    ph = 2*pi*rand(size(h));
    y = zeros(n, 1);
    for k = 1:numel(h)
        y = y + ampLin(k) * sin(2*pi*fH(k)*t + ph(k));
    end

    y = applyFade(y, fs, 0.03);
end

function y = applyFade(y, fs, fadeSec)
    y = y(:);
    m = min(round(fadeSec*fs), floor(numel(y)/2));
    if m <= 1
        return;
    end
    ramp = linspace(0, 1, m).';
    y(1:m) = y(1:m) .* ramp;
    y(end-m+1:end) = y(end-m+1:end) .* flipud(ramp);
end

function [f, magDb] = oneSidedSpectrum(x, fs)
    x = x(:) - mean(x);
    N = numel(x);
    nfft = 2^nextpow2(max(2048, N));
    w = hamming(N);
    X = fft(x .* w, nfft);
    X = X(1:nfft/2+1);
    f = (0:nfft/2).' * fs / nfft;
    magDb = 20*log10(abs(X) + 1e-12);
end

function y = ensureFs(x, fsIn, fsOut)
    x = x(:);
    if fsIn == fsOut
        y = x;
        return;
    end
    y = resample(x, fsOut, fsIn);
end

function seg = extractSteadySegment(x, fs, durSec)
    x = x(:) - mean(x);
    L = max(16, round(durSec * fs));
    if numel(x) <= L
        seg = x;
        return;
    end
    hop = max(1, round(0.005 * fs));
    [st, en] = bestEnergyFrame(x, L, hop);
    seg = x(st:en);
end

function y = smoothByMovingAverage(x, winLen)
    winLen = max(3, round(winLen));
    if mod(winLen, 2) == 0
        winLen = winLen + 1;
    end
    h = ones(winLen, 1) / winLen;
    y = conv(x, h, "same");
end
