%% Lab 3 - Problem 3
% 1) For mhint_01_01.wav, generate noisy speech by white noise at 5 and 0 dB SNR.
% 2) Equalize noisy-speech energy to clean-speech energy.
% 3) Plot waveforms and spectra of clean and equalized noisy speech.
% 4) Plot spectrograms of clean and noisy speech at 5 and 0 dB SNR.

clear; clc; close all;
rng(20260313, "twister");

outDir = fullfile(pwd, "lab3_outputs", "problem3");
if ~exist(outDir, "dir")
    mkdir(outDir);
end

mhintWav = locateSingleFile("mhint_01_01.wav");
[clean, fs] = audioread(mhintWav);
clean = toMonoColumn(clean);
clean = clean - mean(clean);

fprintf("Clean speech: %s\n", mhintWav);

snrList = [5, 0];
noisy = cell(size(snrList));
noisyEq = cell(size(snrList));
measuredSnr = zeros(size(snrList));

%% 1) + 2) Generate noisy speech and equalize energy
for i = 1:numel(snrList)
    [yn, snrMeasured] = addWhiteNoiseAtSNR(clean, snrList(i));
    ye = equalizeEnergy(yn, clean);

    noisy{i} = yn;
    noisyEq{i} = ye;
    measuredSnr(i) = snrMeasured;

    audiowrite(fullfile(outDir, sprintf("P3_noisy_%ddB.wav", snrList(i))), yn, fs);
    audiowrite(fullfile(outDir, sprintf("P3_noisy_eq_%ddB.wav", snrList(i))), ye, fs);
end

fprintf("Measured SNRs: %.2f dB (target 5), %.2f dB (target 0)\n", measuredSnr(1), measuredSnr(2));

%% 3) Plot waveforms and spectra (clean + equalized noisy)
t = (0:numel(clean)-1).' / fs;

fig1 = figure("Name", "Problem3-Waveforms", "Color", "w", ...
    "Position", [100, 100, 800, 600]);

subplot(3, 1, 1);
plot(t, clean, "k");
title("Clean Speech Waveform");
xlabel("Time (s)"); ylabel("Amplitude"); grid on;

subplot(3, 1, 2);
plot(t, noisyEq{1}, "b");
title("Equalized Noisy Speech Waveform (SNR = 5 dB)");
xlabel("Time (s)"); ylabel("Amplitude"); grid on;

subplot(3, 1, 3);
plot(t, noisyEq{2}, "r");
title("Equalized Noisy Speech Waveform (SNR = 0 dB)");
xlabel("Time (s)"); ylabel("Amplitude"); grid on;

saveas(fig1, fullfile(outDir, "P3_waveforms_clean_eq_noisy.png"));

fig2 = figure("Name", "Problem3-Spectra", "Color", "w", ...
    "Position", [150, 150, 800, 600]);
NFFT = 2048;
fAxis = fs * (0:(NFFT/2)) / NFFT;
getSpectrum = @(sig) 20*log10(abs(fft(sig .* hamming(length(sig)), NFFT)) + eps);

Pclean = getSpectrum(clean);
P5 = getSpectrum(noisyEq{1});
P0 = getSpectrum(noisyEq{2});

subplot(3, 1, 1);
plot(fAxis, Pclean(1:NFFT/2+1), "k");
title("Spectrum of Clean Speech");
xlabel("Frequency (Hz)"); ylabel("Magnitude (dB)");
xlim([0 fs/2]); grid on;

subplot(3, 1, 2);
plot(fAxis, P5(1:NFFT/2+1), "b");
title("Spectrum of Equalized Noisy Speech (SNR = 5 dB)");
xlabel("Frequency (Hz)"); ylabel("Magnitude (dB)");
xlim([0 fs/2]); grid on;

subplot(3, 1, 3);
plot(fAxis, P0(1:NFFT/2+1), "r");
title("Spectrum of Equalized Noisy Speech (SNR = 0 dB)");
xlabel("Frequency (Hz)"); ylabel("Magnitude (dB)");
xlim([0 fs/2]); grid on;

saveas(fig2, fullfile(outDir, "P3_spectra_clean_eq_noisy.png"));

%% 4) Spectrograms (clean + noisy)
fig3 = figure("Name", "Problem3-Spectrograms", "Color", "w", ...
    "Position", [200, 200, 800, 600]);
window = round(10e-3 * fs);      % 10 ms window
noverlap = round(window * 0.5);  % 50% overlap

subplot(3, 1, 1);
spectrogram(clean, window, noverlap, NFFT, fs, "yaxis");
title("Spectrogram of Clean Speech");

subplot(3, 1, 2);
spectrogram(noisyEq{1}, window, noverlap, NFFT, fs, "yaxis");
title("Spectrogram of Equalized Noisy Speech (SNR = 5 dB)");

subplot(3, 1, 3);
spectrogram(noisyEq{2}, window, noverlap, NFFT, fs, "yaxis");
title("Spectrogram of Equalized Noisy Speech (SNR = 0 dB)");

saveas(fig3, fullfile(outDir, "P3_spectrograms_clean_noisy.png"));

fprintf("Problem 3 done.\nOutputs saved in: %s\n", outDir);

%% Local functions
function p = locateSingleFile(fileName)
    p = fullfile(pwd, fileName);
    if isfile(p)
        return;
    end

    homeDir = char(java.lang.System.getProperty("user.home"));
    roots = {fullfile(homeDir, "Desktop"), fullfile(homeDir, "Documents"), homeDir};
    for r = 1:numel(roots)
        rootNow = roots{r};
        if ~isfolder(rootNow)
            continue;
        end
        hits = dir(fullfile(rootNow, "**", fileName));
        if ~isempty(hits)
            [~, idx] = max([hits.datenum]);
            p = fullfile(hits(idx).folder, hits(idx).name);
            return;
        end
    end

    error("Cannot find required file: %s", fileName);
end

function x = toMonoColumn(x)
    if size(x, 2) > 1
        x = mean(x, 2);
    end
    x = x(:);
end

function [y, actualSnr] = addWhiteNoiseAtSNR(x, snrDb)
    x = x(:);
    n = randn(size(x));

    pSig = mean(x.^2);
    pN = mean(n.^2);
    targetPn = pSig / (10^(snrDb/10));
    n = n * sqrt(targetPn / (pN + eps));

    y = x + n;
    actualSnr = 10*log10(sum(x.^2) / (sum((y-x).^2) + eps));
end

function yEq = equalizeEnergy(y, xRef)
    y = y(:);
    xRef = xRef(:);
    yEq = y / (norm(y) + eps) * norm(xRef);
end
