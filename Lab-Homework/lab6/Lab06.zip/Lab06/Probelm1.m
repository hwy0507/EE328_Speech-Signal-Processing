%% 问题 1: 复倒谱与实倒谱计算
clear; clc; close all;

% 1. 定义信号参数
N = 101;                % 信号长度 (0 <= n <= 100)
n = 0:N-1;
alpha = 0.85;
D = 100;                % 延迟项

% 生成信号 x1[n] = delta[n] + 0.85 * delta[n - 100]
x1 = zeros(1, N);
x1(1) = 1;              % delta[n]
x1(D + 1) = alpha;      % 0.85 * delta[n-100]

% 2. 准备 FFT (使用较大的 FFT 长度以获得更好的频域采样和避免混叠)
nfft = 1024;            % FFT 点数
X = fft(x1, nfft);      % 计算频谱

% --- 计算复倒谱 (Complex Cepstrum) ---
% 步骤：X(k) -> log|X(k)| + j*unwrap(angle(X(k))) -> IFFT
log_mag = log(abs(X));          % 对数幅度
phase_unwrapped = unwrap(angle(X)); % 相位解包裹 (关键步骤)
X_complex_log = log_mag + 1i * phase_unwrapped;
ccepstrum_manual = real(ifft(X_complex_log)); % 计算逆变换并取实部

% --- 计算实倒谱 (Real Cepstrum) ---
% 步骤：X(k) -> log|X(k)| -> IFFT
X_real_log = log(abs(X));
rcepstrum_manual = real(ifft(X_real_log));


% 3. 绘图展示
figure('Color', 'w');

% 原始信号图
subplot(3, 1, 1);
stem(n, x1, 'filled', 'MarkerSize', 4);
title('原始信号 x_1[n] = \delta[n] + 0.85\delta[n-100]');
xlabel('n'); ylabel('幅度');
grid on;

% 复倒谱图
subplot(3, 1, 2);
t_ceps = 0:nfft-1;
plot(t_ceps, ccepstrum_manual, 'b', 'LineWidth', 1);
hold on;
title('复倒谱');
xlabel('Quefrency'); ylabel('幅度');
xlim([0 nfft/2]); % 观察前半部分
grid on;

% 实倒谱图
subplot(3, 1, 3);
plot(t_ceps, rcepstrum_manual, 'r', 'LineWidth', 1);
title('实倒谱');
xlabel('Quefrency '); ylabel('幅度');
xlim([0 nfft/2]);
grid on;

sgtitle('信号、复倒谱与实倒谱分析');