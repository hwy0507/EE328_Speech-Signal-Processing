% Problem 2
clear; clc; close all;

% 1. 定义待测试的参数集合
a_list = [0.5, 0.9];
N_list = [10, 200];
nfft_list = [10, 16, 256];

fig_idx = 1;

% 2. 嵌套循环进行排列组合测试
for a = a_list
    for N = N_list
        figure('Name', sprintf('a=%.1f, N=%d 组合测试', a, N), 'Color', 'w');
        plot_count = 1;
        
        for nfft = nfft_list
            % --- (1) 生成截断信号 ---
            n = 0:N-1;
            x = a.^n; 
            
            % --- (2) 数值法计算倒谱 (FFT法) ---
            % 第一步：FFT 变换
            X = fft(x, nfft);
            
            % 第二步：取对数并进行相位解卷绕 (unwrap)
            % 这是防止倒谱产生人工跳变的关键步骤
            magX = abs(X);
            phaseX = unwrap(angle(X));
            LogX = log(magX + eps) + 1i * phaseX; % 加 eps 防止 log(0)
            
            % 第三步：IFFT 变回时域
            x_hat_numeric = real(ifft(LogX));
            
            % --- (3) 理论值计算 ---
            % 理论公式：x_hat[0]=ln(1)=0, x_hat[n]=(a^n)/n (n>0)
            n_theory = 0:min(nfft-1, 15); % 对比前15个点
            theory_hat = zeros(size(n_theory));
            theory_hat(2:end) = (a.^(n_theory(2:end))) ./ n_theory(2:end);
            
            % --- (4) 绘图展示 ---
            subplot(1, 3, plot_count);
            stem(0:nfft-1, x_hat_numeric, 'r', 'DisplayName', '数值解'); hold on;
            stem(n_theory, theory_hat, 'b--', 'LineWidth', 1, 'DisplayName', '理论解');
            
            title(sprintf('nfft = %d', nfft));
            xlabel('n (n_q)');
            if plot_count == 1
                ylabel(['a=', num2str(a), ', N=', num2str(N)]);
            end
            axis([0 max(n_theory)+5 min(x_hat_numeric)-0.2 max(x_hat_numeric)+0.2]);
            grid on;
            plot_count = plot_count + 1;
            
            fprintf('%.1f    | %d  | %d    | 已完成\n', a, N, nfft);
        end
        % 调整子图间距
        sgtitle(sprintf('信号 a^n u[n] 的复倒谱分析 (a=%.1f, N=%d)', a, N));
        fig_idx = fig_idx + 1;
    end
end

fprintf('-------------------------------------------\n');
fprintf('所有排列组合计算完毕。\n');