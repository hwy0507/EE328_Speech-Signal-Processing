%% 实验 3：语音信号的复倒谱与实倒谱分析
clear; clc; close all;

% 1. 读取音频文件
[speech, fs] = audioread('test_16k.wav');

% 2. 定义参数
% 浊音段 (Voiced): 起始点 13000, 长度 400
voiced_start = 13000;
len = 400;
voiced_seg = speech(voiced_start : voiced_start + len - 1);

% 清音段 (Unvoiced): 起始点 3400, 长度 400
unvoiced_start = 3400;
unvoiced_seg = speech(unvoiced_start : unvoiced_start + len - 1);

% 定义汉明窗
win = hamming(len);

% 准备处理循环
signals = {voiced_seg, unvoiced_seg};
titles = {'浊音段 (Voiced Speech)', '清音段 (Unvoiced Speech)'};

for i = 1:2
    x = signals{i} .* win; % 加汉明窗
    
    % --- 计算对数幅度谱 ---
    NFFT = 1024;
    X = fft(x, NFFT);
    log_mag_spec = log(abs(X) + eps); % 防止 log(0)
    
    % --- 计算实倒谱 (Real Cepstrum) ---
    % 也可以直接使用 rceps(x) 函数，这里手动实现以体现原理
    real_cep = ifft(log_mag_spec, 'symmetric');
    
    % --- 低频提升 (Liftering) 以获得平滑谱 ---
    % 定义切断点 L，通常取 20-40 左右以保留共振峰信息
    L = 30; 
    lifter = [ones(1, L), zeros(1, NFFT - 2*L + 1), ones(1, L-1)];
    smooth_cep = real_cep' .* lifter; 
    low_que_log_mag = real(fft(smooth_cep));
    
    % --- 绘图 ---
    figure('Name', titles{i}, 'NumberTitle', 'off');
    
    % 1. 原始信号
    subplot(4,1,1);
    plot(signals{i}); title([titles{i}, ' - 原始时域信号']);
    xlabel('样本点'); ylabel('幅度');
    
    % 2. 对数幅度谱
    subplot(4,1,2);
    freq = (0:NFFT/2-1) * fs / NFFT;
    plot(freq, log_mag_spec(1:NFFT/2)); title('对数幅度谱');
    xlabel('频率 (Hz)'); ylabel('dB');
    
    % 3. 实倒谱
    subplot(4,1,3);
    plot(real_cep); title('实倒谱 (Real Cepstrum)');
    xlabel('Quefrency'); ylabel('幅度');
    xlim([0 NFFT/2]);
    
    % 4. 低频提升后的平滑谱 (包络)
    subplot(4,1,4);
    plot(freq, log_mag_spec(1:NFFT/2), 'Color', [0.7 0.7 0.7]); hold on;
    plot(freq, low_que_log_mag(1:NFFT/2), 'r', 'LineWidth', 1.5);
    title('低频提升对数幅度谱 (谱包络)');
    xlabel('频率 (Hz)'); ylabel('dB');
    legend('原始对数谱', '平滑包络');
end