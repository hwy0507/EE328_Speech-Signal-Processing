filename = 'test.wav';

% 1. 检查文件是否存在
if ~exist(filename, 'file')
    error('文件不存在，请检查文件名或当前路径！');
end

% 2. 尝试使用 audioinfo 获取元数据
try
    info = audioinfo(filename);
    disp('文件信息：');
    disp(info);
catch ME
    fprintf('无法解析文件信息。错误原因：%s\n', ME.message);
end

% 3. 尝试读取
try
    [y, fs] = audioread(filename);
    disp('读取成功！');
catch ME
    fprintf('读取失败。建议将文件转换为标准 PCM WAV 格式。\n');
end