%% Voice Recorder for Vowel Analysis
clear; clc;

% 参数设置
fs = 16000;       % 采样率 (16kHz 对语音分析来说非常标准且足够)
nBits = 16;       % 位深
nChannels = 1;    % 单声道 (LPC 分析必须使用单声道)
duration = 3;     % 录音时长 (秒)

% 创建录音对象
recObj = audiorecorder(fs, nBits, nChannels);

% 倒计时提醒
fprintf('准备录音...\n');
pause(1); % 运行后等待1秒

% 开始录音
fprintf('>>> 正在录制 (3秒)... 请发元音 [a] 或 [i]\n');
recordblocking(recObj, duration); % 阻塞式录音，直到时长结束
fprintf('录音结束。\n');
% 获取音频数据
audioData = getaudiodata(recObj);
% 播放录音以确认质量
fprintf('正在回放...\n');
play(recObj);
% 绘制波形图查看录音是否正常
t = (0:length(audioData)-1) / fs;
plot(t, audioData);
xlabel('时间 (s)');
ylabel('幅值');
title('录制的语音波形');
grid on;

% 保存文件
filename = input('请输入保存的文件名 (例如 vowel_a.wav): ', 's');
if isempty(filename)
    filename = 'test_record.wav';
end
audiowrite(filename, audioData, fs);
fprintf('文件已保存为: %s\n', filename);