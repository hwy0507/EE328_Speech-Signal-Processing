% LPC Analysis Assignment - Corrected Version
clear; clc; close all;

%% 1. 参数设置与读取
filename = 'test_16k.wav';
start_sample = 6000;
frame_size = 640;
lpc_order = 12;

% 读取音频文件 (请确保文件在当前路径)
if ~exist(filename, 'file')
    error('找不到文件 %s，请检查路径。', filename);
end
[speech_full, fs] = audioread(filename);

% 提取指定帧
frame_indices = start_sample : (start_sample + frame_size - 1);
x = speech_full(frame_indices);

% 加窗处理 (Hamming 窗可以减少频谱泄露，使包络拟合更准)
w_func = hamming(frame_size);
x_windowed = x .* w_func;

%% 2. LPC 分析计算
% [a, G_var] = lpc(x, p) 
% a: 预测系数 [1, a1, a2, ..., ap]
% G_var: 预测误差功率 (Prediction Error Variance)
[a, G_var] = lpc(x_windowed, lpc_order);

% 计算预测误差信号 (Residual Signal)
% 理论公式: e(n) = x(n) + sum_{k=1}^p a_k * x(n-k)
% 在 MATLAB 中直接用 filter 实现逆滤波
err_sig = filter(a, 1, x); 


%% 3. 频谱计算与对齐 (能量归一化)
nfft = 1024;
N = length(x_windowed); % 帧长，通常为 640

% (A) 计算原始信号的对数幅度谱
% 关键：保持 FFT 的线性值，不进行人为缩小
X_fft = fft(x_windowed, nfft);
X_mag = abs(X_fft(1:nfft/2+1));
X_db = 20*log10(X_mag + eps); 

% (B) 计算 LPC 包络
% 理论公式：H(z) = G / A(z)
% MATLAB 的 lpc(x,p) 返回的 G_var 是残差功率。
% 为了让包络对齐 FFT 幅度谱，必须乘上 sqrt(N) 来补偿 FFT 的累加效应
G = sqrt(G_var * N); 

[h_inv_A, ~] = freqz(1, a, nfft/2+1);
LPC_mag = G * abs(h_inv_A);
LPC_db = 20*log10(LPC_mag + eps);

% (C) 误差信号频谱 (同样方式处理)
E_fft = fft(err_sig .* hamming(length(err_sig)), nfft);
E_db = 20*log10(abs(E_fft(1:nfft/2+1)) + eps);
%% 4. 绘图展示
figure('Color', 'w', 'Position', [100, 100, 800, 900]);

% (1) 原始语音帧
subplot(4,1,1);
plot(frame_indices, x, 'Color', [0, 0.447, 0.741]);
title('Original Speech Frame (Time Domain)');
xlabel('Sample Index'); ylabel('Amplitude'); grid on;

% (2) LPC 误差信号 (残差)
subplot(4,1,2);
plot(frame_indices, err_sig, 'Color', [0.85, 0.325, 0.098]);
title('LPC Error Signal (Residual)');
xlabel('Sample Index'); ylabel('Amplitude'); grid on;

% (3) 频谱对比: STFT vs LPC 包络
subplot(4,1,3);
f_axis = (0:nfft/2) * (fs/nfft);
plot(f_axis, X_db, 'Color', [0.7, 0.7, 0.7], 'DisplayName', 'Signal Spectrum (FFT)'); 
hold on;
plot(f_axis, LPC_db, 'r', 'LineWidth', 1.5, 'DisplayName', 'LPC Envelope');
title('Spectral Analysis: Original vs LPC');
xlabel('Frequency (Hz)'); ylabel('Magnitude (dB)');
legend('Location', 'northeast'); grid on;
ylim([max(X_db)-60, max(X_db)+10]); % 自动调整纵坐标范围以便观察

% (4) 误差信号频谱
subplot(4,1,4);
plot(f_axis, E_db, 'Color', [0.466, 0.674, 0.188]);
title('Error Signal Log Magnitude Spectrum');
xlabel('Frequency (Hz)'); ylabel('Magnitude (dB)'); grid on;
ylim([max(E_db)-60, max(E_db)+10]);

% 整体布局优化
sgtitle(['LPC Analysis (Order = ', num2str(lpc_order), ')'], 'FontSize', 14);