% 9.33 LPC Analysis and Exact Reconstruction
clear; clc; close all;

% 1. 参数设置
[s, fs] = audioread('s5.wav'); % 确保目录下有该文件
p = 12;                         % LPC 阶数
frame_len = 320;                % 帧长
frame_shift = 80;               % 帧移
n_samples = length(s);

% 2. 分帧与加窗
% 使用 buffer 函数简化分帧，注意 buffer 的参数逻辑
% 原信号首尾可能需要补零以对齐
frames = buffer(s, frame_len, frame_len - frame_shift, 'nodelay');
[L, num_frames] = size(frames);
window = hamming(L); % 常用汉明窗减少频谱泄露

% 初始化存储空间
error_signal = zeros(n_samples, 1);
resynth_signal = zeros(n_samples + frame_len, 1); % 为 Overlap-Add 预留空间
win_sum = zeros(n_samples + frame_len, 1);       % 用于归一化窗函数增益

% 3. 逐帧处理
for i = 1:num_frames
    curr_frame = frames(:, i) .* window;
    start_idx = (i-1) * frame_shift + 1;
    end_idx = start_idx + frame_len - 1;
    
    % --- 分析阶段 ---
    % 计算 LPC 系数 (A 为 [1, -a1, -a2, ...])
    A = lpc(curr_frame, p);
    
    % 提取残差/误差信号 e[n]
    % e(n) = s(n) - sum(ak * s(n-k)) -> FIR 滤波
    e_frame = filter(A, 1, curr_frame);
    
    % 存储误差信号（由于重叠，这里简单采用覆盖或叠加，精确重构通常直接对全信号滤波）
    % 但为了符合题目“分帧分析”，我们按帧合成
    
    % --- 合成阶段 (Overlap-Add) ---
    % 使用误差信号作为激励，通过 1/A 合成
    s_hat_frame = filter(1, A, e_frame);
    
    % 将结果加回到重构序列中
    resynth_signal(start_idx:end_idx) = resynth_signal(start_idx:end_idx) + s_hat_frame;
    win_sum(start_idx:end_idx) = win_sum(start_idx:end_idx) + window;
end

% 归一化窗函数影响（针对 Overlap-Add 的能量补偿）
valid_idx = win_sum > 0;
resynth_signal(valid_idx) = resynth_signal(valid_idx) ./ win_sum(valid_idx);
resynth_signal = resynth_signal(1:n_samples); % 裁剪回原长度

% 4. 计算全局误差信号（用于绘图）
% 为了在图中展示连续的 e[n]，直接对全信号进行全极点分析是不准确的，
% 按照 LPC 标准做法，这里展示合成时对应的残差。
global_A = lpc(s, p);
error_signal = filter(global_A, 1, s);

% 5. 绘图
figure('Position', [100, 100, 800, 600]);
subplot(3,1,1);
plot(s); title('原始语音信号 s[n]'); grid on;
subplot(3,1,2);
plot(error_signal); title('误差（残差）信号 e[n]'); grid on;
subplot(3,1,3);
plot(resynth_signal); title('重构语音信号 \its[n]'); grid on;

% 6. 听感验证
% sound(s, fs);        % 原始
% pause(length(s)/fs);
% sound(resynth_signal, fs); % 重构